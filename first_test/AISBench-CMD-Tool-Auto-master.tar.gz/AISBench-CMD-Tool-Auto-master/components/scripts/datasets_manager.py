import json
import os
import re
import ast
import shutil

from transformers import AutoTokenizer

from components.utils.help_text import HelpText
from components.utils.logger import LOGGER
from components.utils.path_util import PathUtil
from components.utils.utils import Utils


class DatasetsManager:
    data_name = ''
    dataset_path = ''
    tokenizer_path = ''

    @classmethod
    def _process_synthetic(cls, in_len, out_len, dataset_len):
        synthetic_config_path = os.path.join(cls.dataset_path, "synthetic_config.py")

        with open(synthetic_config_path, "r+") as f:
            lines = f.readlines()
            output_flag = False
            for i, line in enumerate(lines):
                if '"RequestCount"' in line:
                    lines[i] = f'    "RequestCount": {dataset_len}, # 生成的请求条数，应与模型侧配置文件中的 decode_batch_size 一致\n'
                if '"Output"' in line:
                    output_flag = True
                if '"Params"' in line:
                    if output_flag:
                        lines[i] = f'            "Params": {{"MinValue": {out_len}, "MaxValue": {out_len}}}\n'
                    else:
                        lines[i] = f'            "Params": {{"MinValue": {in_len}, "MaxValue": {in_len}}}\n'

            f.seek(0)
            f.write("".join(lines))
            f.truncate()

    @classmethod
    def _process_gsm8k(cls, batch_size, input_len):
        new_file_path = os.path.join(PathUtil.get_resources_root_dir_path(), f'GSM8K-in{input_len}-bs{batch_size}.jsonl')
        if os.path.exists(new_file_path):
            Utils.log_debug_and_print(HelpText.GSM8K_SKIP.format(new_file_path))
            return new_file_path
        dataset_path = os.path.join(PathUtil.get_resources_root_dir_path(), "GSM8K.jsonl")
        dataset = []
        tokenizer = AutoTokenizer.from_pretrained(cls.tokenizer_path)
        with open(dataset_path, 'r', encoding="utf-8") as f:
            for line in f:
                data = json.loads(line)
                dataset.append(data['question'])

        # repeat input_len
        dataset_2k = []
        for sentence in dataset:
            words = tokenizer.tokenize(sentence)
            LOGGER.info(len(words))
            len_num = len(words) // input_len
            if len_num == 0:
                multiplier = (input_len // len(words)) + 1
                repeated_len = words * multiplier
                words = repeated_len[:input_len]
                decoded_text = tokenizer.convert_tokens_to_string(words)
                LOGGER.info(len(words))
                dataset_2k.append(decoded_text)
            # else:
            #    words = words[:input_len]
            #    merged_sentence = " ".join(words)  # 合并
            #    print(len(words))
            #    dataset_2k.append(merged_sentence)

        # repeat to batch_size
        batch_num = len(dataset_2k) // batch_size
        if batch_num == 0:
            multiplier = (batch_size // len(dataset_2k)) + 1
            repeated_batch = dataset_2k * multiplier
            dataset_2k = repeated_batch[:batch_size]
        else:
            dataset_2k = dataset_2k[:batch_size]

        LOGGER.info(len(dataset_2k))

        json_str = json.dumps(dataset_2k, ensure_ascii=False, indent=4)

        with open(new_file_path, 'w', encoding='utf-8') as f:
            for i in range(len(dataset_2k)):
                f.write(json.dumps({"question": dataset_2k[i], "answer": "none"}, ensure_ascii=False))
                f.write("\n")
        Utils.log_info_and_print(HelpText.GSM8K_SUCCESS.format(new_file_path))
        return new_file_path

    @classmethod
    def _replace_gsm8k(cls, data_path):
        gsm8k_path = os.path.join(cls.dataset_path, "test.jsonl")
        shutil.copy2(data_path, gsm8k_path)
        train_path = os.path.join(cls.dataset_path, "train.jsonl")
        if not os.path.exists(train_path):
            with open(train_path, 'w', encoding='utf-8') as f:
                f.write("{}")
        Utils.log_info_and_print(HelpText.GSM8K_REPLACE.format(gsm8k_path, data_path))

    @classmethod
    def init_datasets(cls, data_name, ais_path, tokenizer_path):
        cls.data_name = data_name
        cls.tokenizer_path = tokenizer_path
        cls.dataset_path = os.path.join(ais_path, "ais_bench/datasets", data_name)
        Utils.make_dirs(cls.dataset_path)

    @classmethod
    def process_dataset(cls, input_len, output_len, dataset_len):
        LOGGER.debug(f"input_len: {input_len}, output_len: {output_len}, dataset_len: {dataset_len}")
        Utils.log_debug_and_print(HelpText.DATASET_PROCESS_START)
        if cls.data_name == 'synthetic':
            cls._process_synthetic(input_len, output_len, dataset_len)
        elif cls.data_name == 'gsm8k':
            new_file_path = cls._process_gsm8k(int(dataset_len), int(input_len))
            cls._replace_gsm8k(new_file_path)
        Utils.log_debug_and_print(HelpText.DATASET_PROCESS_END)
