import os

from components.utils.help_text import HelpText
from components.utils.logger import LOGGER
from components.utils.utils import Utils


class ConfigManager:
    engine_name = ''
    config_path = ''
    model_path = ''
    api_name = ''

    @classmethod
    def _process_mindie(cls, output_len, concurrency, request_rate):
        mindie_config_path = os.path.join(cls.config_path, cls.api_name + ".py")
        with open(mindie_config_path, "r+") as f:
            lines = f.readlines()
            for i, line in enumerate(lines):
                if 'path' in line:
                    lines[i] = f'        path="{cls.model_path}",\n'
                if 'max_out_len' in line:
                    lines[i] = f'        max_out_len = {output_len},\n'
                if 'request_rate' in line:
                    lines[i] = f'        request_rate = {request_rate},\n'
                if 'batch_size' in line:
                    lines[i] = f'        batch_size= {concurrency},\n'

            f.seek(0)
            f.write("".join(lines))
            f.truncate()
        Utils.log_info_and_print(HelpText.CONFIG_PROCESS_FINISH.format('mindie', mindie_config_path))

    @classmethod
    def _process_vllm(cls, output_len, concurrency, request_rate):
        vllm_config_path = os.path.join(cls.config_path, cls.api_name + ".py")
        with open(vllm_config_path, "r+") as f:
            lines = f.readlines()
            for i, line in enumerate(lines):
                if 'path' in line:
                    lines[i] = f'        path="{cls.model_path}",\n'
                if 'max_out_len' in line:
                    lines[i] = f'        max_out_len = {output_len},\n'
                if 'request_rate' in line:
                    lines[i] = f'        request_rate = {request_rate},\n'
                if 'batch_size' in line:
                    lines[i] = f'        batch_size= {concurrency},\n'

            f.seek(0)
            f.write("".join(lines))
            f.truncate()
        Utils.log_info_and_print(HelpText.CONFIG_PROCESS_FINISH.format('vllm', vllm_config_path))

    @classmethod
    def init_config(cls, engine_name, ais_path, model_path, api_name):
        cls.api_name = api_name
        cls.engine_name = engine_name
        cls.model_path = model_path
        cls.config_path = os.path.join(ais_path, "ais_bench/benchmark/configs/models", engine_name + "_api")

    @classmethod
    def process_config(cls, output_len, concurrency, request_rate):
        LOGGER.debug(f"output_len:{output_len}, concurrency:{concurrency}, request_rate:{request_rate}")
        Utils.log_debug_and_print(HelpText.CONFIG_PROCESS_START)
        if cls.engine_name == 'mindie':
            cls._process_mindie(output_len, concurrency, request_rate)
        elif cls.engine_name == 'vllm':
            cls._process_vllm(output_len, concurrency, request_rate)
        Utils.log_debug_and_print(HelpText.CONFIG_PROCESS_END)






