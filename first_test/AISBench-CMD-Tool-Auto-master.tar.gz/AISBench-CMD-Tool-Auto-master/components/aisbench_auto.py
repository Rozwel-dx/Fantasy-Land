#!/usr/bin/env python
# _*_ encoding:utf-8 _*_
# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.
import copy
import csv
import json
import os
import signal
import subprocess
import sys
import traceback

current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(current_dir))

from components.view.d2_printer import D2Printer
from components.utils.language import Language
from components.utils.path_util import PathUtil
from components.utils.errcode import ErrCode
from components.utils.help_text import HelpText
from components.utils.logger import LOGGER, Output, LoggerHandler
from components.utils.parser import CustomArgumentParser, CustomFormatter
from components.utils.utils import CustomError, Utils, LOGGER_PATH
from components.scripts.datasets_manager import DatasetsManager
from components.scripts.config_manager import ConfigManager
from components.view.d1_printer import D1Printer

PRODUCT_NAME = "AISBench-CMD-Tool-Auto"


class AISBenchAuto:
    vision = "V1.0"
    TTFT_AVG = 'TTFT AVG'
    TTFT_P90 = 'TTFT P90'
    TPOT_AVG = "TPOT AVG"
    TPOT_P90 = 'TPOT P90'
    E2E_TIME = 'E2ET'
    CON = 'Con'
    TOTAL_TOKENS = 'Total Tokens'
    OUTPUT_TOKENS = 'Output Tokens'
    QPS = 'QPS'


    summarizer_map = {
        'example': 'total',
        'medium': '',
        'default_perf': 'total',
        'stable_stage': 'stable'
    }

    def __init__(self):
        self.api_name = None
        self.args = None
        self.parser = None
        # 指定AISBench安装路径
        self.ais_path = None
        # 指定tokenizer路径
        self.model_path = None
        # input_lens/output_lens/dataset_lens/concurrency：输入输出长度、数据集条数、最大并发组合，需一一对应
        self.input_lens = []
        self.output_lens = []
        self.dataset_lens = []
        self.max_concurrency = []
        self.descend_limits = 0
        # 自动请求频率开关，若开启则会遍历当前并发的2幂数；例：并发18，请求频率为[0, 2, 4, 8, 16, 18]
        self.auto_request_rate = False
        # 请求频率开关为false，会遍历该列表的请求频率，默认为[0]
        self.request_rate = [0]
        #  数据集类型，默认合成数据集
        self.dataset_type = None

        Language.check_language()
        LoggerHandler.set_log_level(3)
        # Register signal handlers to capture exit signals
        signal.signal(signal.SIGINT, self.handle_sigint)  # Handle Ctrl+C (SIGINT)
        signal.signal(signal.SIGTSTP, self.handle_sigtstp)  # Handle Ctrl+Z (SIGTSTP)

    def parse_args(self):
        """
        Parse command line arguments
        """

        parser = CustomArgumentParser(description=PRODUCT_NAME + " " + self.vision, add_help=False,
                                      formatter_class=CustomFormatter, prog=PRODUCT_NAME)

        parser.add_argument('--home', type=str, required=True, help=HelpText.AIS_PATH)
        parser.add_argument('--model-path', type=str, required=True, help=HelpText.MODEL_PATH)
        parser.add_argument('--engine', type=str, choices=['vllm', 'mindie'], default='vllm', help=HelpText.ENGINE)

        parser.add_argument('--summarizer', type=str, choices=['example', 'medium', 'default_perf', 'stable_stage'],
                            default='default_perf', help=HelpText.SUMMARIZER)

        parser.add_argument('--input-length', type=str, default='0', help=HelpText.MAX_INPUT_LEN)
        parser.add_argument('--output-length', type=str, default='20', help=HelpText.MAX_OUTPUT_LEN)
        parser.add_argument('--request-num', type=str, default='0', help=HelpText.DATASET_LEN)

        parser.add_argument('--tpot-limits', type=int, default='0', help=HelpText.AUTO_TPOT)
        parser.add_argument('--descend-method', type=str, choices=['CON', 'RR'], default='CON',
                            help=HelpText.AUTO_TPOT_METHOD)
        parser.add_argument('--descend-limits', type=int, default=0, help=HelpText.APPROACH_UPPER)
        parser.add_argument('--concurrency', type=str, default='1', help=HelpText.CONCURRENCY)

        parser.add_argument('--auto-rr', type=bool, default=False, help=HelpText.AUTO_REQUEST_RATE)
        parser.add_argument('--rr', type=str, default='0', help=HelpText.REQUEST_RATE)
        parser.add_argument('--dataset-type', type=str, choices=['synthetic', 'gsm8k'], default='gsm8k',
                            help=HelpText.DATASET_TYPE)

        parser.add_argument('-L', '--log-level', type=int, choices=range(0, 5), default=4, help=HelpText.LOG)
        parser.add_argument('-l', '--language', type=int, choices=range(0, 2), default=1, help=HelpText.LAN)
        self.parser = parser
        self.args = parser.parse_args()
        LoggerHandler.set_log_level(self.args.log_level)
        Language.set_language(self.args.language)
        self.parse_aispath()
        self.parse_model_path()
        self.parse_sub_parser()

    def parse_aispath(self):
        path = self.args.home
        if not os.path.exists(path):
            Utils.log_error_and_print(ErrCode.AISBENCH_NOT_EXIST)
        self.ais_path = path

    def parse_model_path(self):
        path = self.args.model_path
        if not os.path.exists(path):
            Utils.log_error_and_exit(ErrCode.MODEL_NOT_EXIST)

        if self.args.engine == 'mindie':
            self.api_name = "mindie_stream_api_general"
        elif self.args.engine == 'vllm':
            self.api_name = "vllm_api_general_stream"
        else:
            self.api_name = "tgi_stream_api_general"

        self.model_path = path

    def parse_sub_parser(self):
        self.input_lens = Utils.parse_range(self.args.input_length, int)
        self.output_lens = Utils.parse_range(self.args.output_length, int)

        if self.args.descend_limits == 0:
            if self.args.descend_method == 'CON':
                self.descend_limits = 256
            elif self.args.descend_method == 'RR':
                self.descend_limits = 10
        else:
            self.descend_limits = self.args.descend_limits

        if self.args.tpot_limits and self.args.descend_method == 'CON':
            self.max_concurrency = [0 for _ in self.input_lens]
            self.dataset_lens = [0 for _ in self.input_lens]
        else:
            self.max_concurrency = Utils.parse_range(self.args.concurrency, int)

        if self.args.request_num == '0':
            dataset_lens = [4 * max_c for max_c in self.max_concurrency]
            self.dataset_lens = dataset_lens
            LOGGER.info(HelpText.SET_REQUEST_NUM.format(dataset_lens))
        else:
            self.dataset_lens = Utils.parse_range(self.args.request_num, int)

        self.dataset_type = self.args.dataset_type
        if not len(self.input_lens) == len(self.output_lens) == len(self.dataset_lens) == len(self.max_concurrency):
            LOGGER.error(f'input_lens: {self.input_lens}, output_lens: {self.output_lens}, '
                         f'dataset_lens: {self.dataset_lens}, max_concurrency: {self.max_concurrency}')
            Utils.log_error_and_exit(ErrCode.INPUT_OUTPUT_DATASET_NOT_MATCH)
        self.auto_request_rate = self.args.auto_rr
        if not self.auto_request_rate:
            self.request_rate = Utils.parse_range(self.args.rr, float)

    def handle_sigint(self, signum, frame):
        """Handle Ctrl+C (SIGINT) interruption"""
        Output.message(HelpText.EXIT_C)
        self.cleanup()  # Perform cleanup operations
        raise CustomError(ErrCode.EXIT, 0)  # Exit the program gracefully

    def handle_sigtstp(self, signum, frame):
        """Handle Ctrl+Z (SIGTSTP) stop signal"""
        Output.message(HelpText.EXIT_Z)
        self.cleanup()  # Perform cleanup operations
        raise CustomError(ErrCode.EXIT, 0)  # Exit the program gracefully

    @staticmethod
    def cleanup():
        """Cleanup resources before exit"""
        Output.message(HelpText.CLEANING)
        # Perform resource cleanup here (e.g., close files, release connections)
        Utils.kill_process()
        LOGGER.info("Cleanup completed, exiting the program.")

    def generate_request_rate(self, concurrency):
        if self.auto_request_rate:
            # 例：并发18，请求频率为[0, 2, 4, 8, 16, 18]
            return Utils.get_powers_of_two(concurrency) + [concurrency]
        else:
            return self.request_rate

    def get_task_result(self):
        """
        ********* locate in outputs/default/20250829_113535/performances/mindie-stream-api.
        找到最大时间长度的报告并读取
        :return:
        """
        output_path = os.path.join(self.ais_path, 'outputs', 'default')
        latest_report_name = max(os.listdir(output_path))
        latest_report_path = os.path.join(output_path, latest_report_name, 'performances',
                                          self.api_name.replace('_', '-'))
        LOGGER.info(f'Find latest_report_path {latest_report_path}')
        performance_result_csv = os.path.join(self.ais_path, latest_report_path, self.dataset_type + "dataset.csv")
        performance_result_json = os.path.join(self.ais_path, latest_report_path, self.dataset_type + "dataset.json")
        if not os.path.exists(performance_result_csv) or not os.path.exists(performance_result_json):
            Utils.log_error_and_exit(ErrCode.NO_PERFORMANCE_RESULT)
        data_dict = {
            self.TTFT_AVG: '',
            self.TTFT_P90: '',
            self.TPOT_AVG: '',
            self.TPOT_P90: '',
            self.E2E_TIME: '0',
            self.CON: '0',
            self.TOTAL_TOKENS: '',
            self.OUTPUT_TOKENS: '',
            self.QPS: '0',
        }
        with open(performance_result_csv, mode='r', encoding='utf-8') as csv_file:
            # 使用csv.DictReader读取CSV，自动将首行作为字段名
            csv_reader = csv.DictReader(csv_file)

            for row in csv_reader:
                performance_parameters = row.get('Performance Parameters', '')
                if performance_parameters == 'TTFT':
                    data_dict[self.TTFT_AVG] = row.get('Average', '').replace(' ms', '')
                    data_dict[self.TTFT_P90] = row.get('P90', '').replace(' ms', '')
                elif performance_parameters == 'TPOT':
                    data_dict[self.TPOT_AVG] = row.get('Average', '').replace(' ms', '')
                    data_dict[self.TPOT_P90] = row.get('P90', '').replace(' ms', '')
        Utils.log_info_and_print(HelpText.READ_PERFORMANCE_RESULT.format(performance_result_csv))
        json_key = self.summarizer_map.get(self.args.summarizer, 'total')
        with open(performance_result_json, 'r') as json_file:
            json_dict = json.load(json_file)
            data_dict[self.E2E_TIME] = Utils.from_ms_to_s(json_dict.get('Benchmark Duration', {}).get(json_key, '0'))
            data_dict[self.CON] = json_dict.get('Concurrency', {}).get(json_key, '0')
            data_dict[self.QPS] = json_dict.get('Request Throughput', {}).get(json_key, '').replace(' req/s', '0')
            data_dict[self.TOTAL_TOKENS] = json_dict.get('Total Token Throughput',
                                                         {}).get(json_key, '0').replace(' token/s', '0')
            data_dict[self.OUTPUT_TOKENS] = json_dict.get('Output Token Throughput',
                                                          {}).get(json_key, '').replace(' token/s', '0')
        Utils.log_info_and_print(HelpText.READ_PERFORMANCE_RESULT.format(performance_result_json))
        return data_dict

    def run_aisbench(self, index):
        if self.args.dataset_type == 'gsm8k':
            datasets = "gsm8k_gen_0_shot_cot_str_perf"
        else:
            datasets = "synthetic_gen"
        args = ["ais_bench",
                "--models", self.api_name,
                "--datasets", datasets,
                '--summarizer', self.args.summarizer,
                "--mode", "perf",
                "--debug"]
        Utils.log_debug_and_print(HelpText.RUN_AISBENCH.format(index, args))
        subprocess.run(args)
        # return_code, result = Utils.run_command_with_realtime_output(args)
        # if return_code != 0:
        #     Utils.log_error_and_exit(ErrCode.RUN_ERROR.format(index, LOGGER_PATH))
        task_dict = self.get_task_result()
        Utils.log_info_and_print(HelpText.RUN_COMPLETED.format(index))
        return task_dict

    def auto_approach_tpot_task_with_con(self):
        """
        通过调整最大并发以卡给定的TPOT，+-1
        :return:
        """
        target_tpot = self.args.tpot_limits
        request_rate = self.request_rate[0]
        result_dict = {}
        index = 1
        for i in range(len(self.input_lens)):
            # 并发上下界
            concurrency_upper = self.descend_limits
            concurrency_lower = 0
            max_concurrency = concurrency_upper
            input_len = self.input_lens[i]
            output_len = self.output_lens[i]
            current_tpot = 0
            while concurrency_lower <= concurrency_upper:
                # 修改配置文件
                previous_concurrency = max_concurrency
                max_concurrency = (concurrency_lower + concurrency_upper) // 2
                Utils.log_debug_and_print(HelpText.ADJUST_CONFIG.format('Max Concurrency', previous_concurrency,
                                                                        max_concurrency))
                dataset_len = 4 * max_concurrency

                # 处理数据集
                DatasetsManager.process_dataset(input_len, output_len, dataset_len)
                ConfigManager.process_config(output_len, max_concurrency, request_rate)
                # 打印当前配置
                D1Printer.display_info({
                    'Inference engine': self.args.engine,
                    'Dataset Type': self.args.dataset_type,
                    'Input Length': input_len,
                    'Output Length': output_len,
                    'Dataset Length': dataset_len,
                    'Max Concurrency': max_concurrency,
                    'Request Rate': request_rate
                }, f'Approach Task {index}')
                # 拉起AISBench
                task_dict = self.run_aisbench(index)
                # 检查TPOT AVG是否符合要求或二分法越界
                previous_tpot = current_tpot
                current_tpot = float(task_dict[self.TPOT_AVG])
                if (target_tpot - 1 <= current_tpot <= target_tpot + 1 or
                        concurrency_upper <= concurrency_lower or 0 < (current_tpot - previous_tpot) < 1):
                    length = len(result_dict) + 1
                    result = {
                        'Input Len': input_len,
                        'Output Len': output_len,
                        'Dataset Len': dataset_len,
                        'Max Con': max_concurrency,
                        'RR': request_rate,
                        **task_dict
                    }
                    if len(self.input_lens) != 1:
                        cur_tpot = task_dict[self.TPOT_AVG]
                        if 0 < (current_tpot - previous_tpot) < 1:
                            Utils.log_warning_and_print(HelpText.APPROACH_TASK_BLOCKED.format(cur_tpot, target_tpot))
                        else:
                            Utils.log_info_and_print(HelpText.APPROACH_TASK_SUCCESS.format(cur_tpot, target_tpot))
                        D2Printer.display_table_info({index: copy.deepcopy(result)})
                    result_dict[length] = result
                    index += 1
                    break

                if current_tpot < target_tpot:
                    concurrency_lower = max_concurrency + 1
                else:
                    concurrency_upper = max_concurrency - 1
                index += 1
        Utils.log_info_and_print(HelpText.ALL_TASKS_COMPLETED.format(index - 1))
        return result_dict

    def auto_approach_tpot_task_with_rr(self):
        """
        通过调整请求频率以卡给定的TPOT，+-1
        :return:
        """
        target_tpot = self.args.tpot_limits
        result_dict = {}
        index = 1
        for i in range(len(self.input_lens)):
            max_concurrency = self.max_concurrency[i]
            # 并发上下界
            request_rate = request_rate_upper = self.descend_limits
            request_rate_lower = 0

            input_len = self.input_lens[i]
            output_len = self.output_lens[i]
            dataset_len = self.dataset_lens[i]
            # 处理数据集
            DatasetsManager.process_dataset(input_len, output_len, dataset_len)
            while request_rate_lower <= request_rate_upper:
                # 修改配置文件
                previous_request_rate = request_rate
                request_rate = round((request_rate_lower + request_rate_upper) / 2, 4)
                Utils.log_debug_and_print(HelpText.ADJUST_CONFIG.format('Request Rate', previous_request_rate,
                                                                        request_rate))
                ConfigManager.process_config(output_len, max_concurrency, request_rate)
                # 打印当前配置
                D1Printer.display_info({
                    'Inference engine': self.args.engine,
                    'Dataset Type': self.args.dataset_type,
                    'Input Length': input_len,
                    'Output Length': output_len,
                    'Dataset Length': dataset_len,
                    'Max Concurrency': max_concurrency,
                    'Request Rate': request_rate
                }, f'Approach Task {index}')
                # 拉起AISBench
                task_dict = self.run_aisbench(index)
                # 检查TPOT AVG是否符合要求或二分法越界
                current_tpot = float(task_dict[self.TPOT_AVG])
                if (target_tpot - 1 <= current_tpot <= target_tpot + 1 or
                        request_rate_upper <= request_rate_lower):
                    length = len(result_dict) + 1
                    result = {
                        'Input Len': input_len,
                        'Output Len': output_len,
                        'Dataset Len': dataset_len,
                        'Max Con': max_concurrency,
                        'RR': request_rate,
                        **task_dict
                    }
                    if len(self.input_lens) != 1:
                        Utils.log_info_and_print(HelpText.APPROACH_TASK_SUCCESS.format(target_tpot))
                        D2Printer.display_table_info({index: copy.deepcopy(result)})
                    result_dict[length] = result
                    index += 1
                    break

                if current_tpot < target_tpot:
                    request_rate_lower = request_rate
                else:
                    request_rate_upper = request_rate
                index += 1
        Utils.log_info_and_print(HelpText.ALL_TASKS_COMPLETED.format(index - 1))
        return result_dict

    def enter(self):
        os.chdir(self.ais_path)
        DatasetsManager.init_datasets(self.args.dataset_type, self.ais_path, self.model_path)
        ConfigManager.init_config(self.args.engine, self.ais_path, self.model_path, self.api_name)
        if self.args.tpot_limits:
            if self.args.descend_method == 'RR':
                result_dict = self.auto_approach_tpot_task_with_rr()
            else:
                result_dict = self.auto_approach_tpot_task_with_con()
        else:
            result_dict = self.default_task()
        D2Printer.display_table_info(result_dict)

    def default_task(self):
        result_dict = {}
        index = 1
        length = len(self.input_lens)
        for i in range(length):
            input_len = self.input_lens[i]
            output_len = self.output_lens[i]
            dataset_len = self.dataset_lens[i]
            max_concurrency = self.max_concurrency[i]
            # 首先处理数据集
            DatasetsManager.process_dataset(input_len, output_len, dataset_len)
            request_rates = self.generate_request_rate(int(max_concurrency))
            for request_rate in request_rates:
                # 修改配置文件
                ConfigManager.process_config(output_len, max_concurrency, request_rate)
                # 打印当前配置
                D1Printer.display_info({
                    'Inference engine': self.args.engine,
                    'Dataset Type': self.args.dataset_type,
                    'Input Length': input_len,
                    'Output Length': output_len,
                    'Dataset Length': dataset_len,
                    'Max Concurrency': max_concurrency,
                    'Request Rate': request_rate
                }, f'Default Task {index}')
                # 拉起AISBench
                task_dict = self.run_aisbench(index)
                result_dict[index] = {
                    'Input Len': input_len,
                    'Output Len': output_len,
                    'Dataset Len': dataset_len,
                    'Max Con': max_concurrency,
                    'RR': request_rate,
                    **task_dict
                }
                if index < length:
                    D2Printer.display_table_info({index: result_dict[index]})
                index += 1
        Utils.log_info_and_print(HelpText.ALL_TASKS_COMPLETED.format(index - 1))
        return result_dict


if __name__ == '__main__':
    aisbench_auto = AISBenchAuto()
    try:
        aisbench_auto.parse_args()
    except (SystemExit, CustomError) as e:
        # Handle errors by printing help and then exiting
        LOGGER.error(traceback.format_exc())
        if hasattr(e, 'code') and e.code != 0:  # Only exit with error if exit code is non-zero
            aisbench_auto.parser.print_help()
        sys.exit(0)
    except Exception as e:
        LOGGER.error(e)
        t = traceback.format_exc()
        LOGGER.error(t)
        Utils.log_error_and_print(ErrCode.COMMON_ERROR.format(LOGGER_PATH))
        sys.exit(2)

    try:
        aisbench_auto.enter()
    except ValueError as e:
        LOGGER.error(traceback.format_exc())
        Utils.log_error_and_print(e)
        sys.exit(2)
    except CustomError as e:
        LOGGER.error(e)
        LOGGER.error(traceback.format_exc())
        if hasattr(e, 'code'):
            sys.exit(int(e.code))
        sys.exit(0)
    except Exception as e:
        LOGGER.error(e)
        LOGGER.error(traceback.format_exc())
        Utils.log_error_and_print(ErrCode.COMMON_ERROR.format(LOGGER_PATH))
