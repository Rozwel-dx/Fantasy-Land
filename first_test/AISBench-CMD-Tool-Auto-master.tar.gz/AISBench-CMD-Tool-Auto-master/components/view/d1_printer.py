# coding:utf-8
# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.
"""
Description: cmd views
Copyright: Copyright © Huawei Technologies Co., Ltd. 2025. All rights reserved.
Python version: 3.7
"""
import textwrap
from components.utils.logger import Output
from components.utils.utils import Utils

UP_LEFT = "┌"
UP_RIGHT = "┐"
LOWER_LEFT = "└"
LOWER_RIGHT = "┘"
HORIZONTAL = "─"
VERTICAL = "│"
LEFT = "├"
RIGHT = "┤"


class D1Printer:
    @staticmethod
    def display_info(info_dict: dict, title: str):
        """
        Display info in module style
        """
        if not info_dict:
            return
        # Calculate the max length to make the box fit all contents
        max_title_length = max(max(len(str(value)) for value in info_dict.keys()) + 1, 20)
        max_data_length = min(Utils.get_max_string_length(info_dict), 60)
        max_length = max_title_length + max_data_length + 3  # Additional padding for spaces

        # Top border of the box
        Output.message(UP_LEFT + HORIZONTAL * max_length + UP_RIGHT)
        Output.message("{} {} {}".format(VERTICAL, title.center(max_length - 2), VERTICAL))
        Output.message("{} {} {}".format(VERTICAL, ''.center(max_length - 2), VERTICAL))

        # Output.message each line of the box with centered content
        for name, value in info_dict.items():
            # Split the value into lines and wrap each line to fit within max_data_length
            lines = str(value).splitlines()
            wrapped_lines = []
            for line in lines:
                wrapped_lines.extend(textwrap.wrap(line, width=max_data_length))

            first_line = True  # Flag to check if it's the first line for this entry

            for line in wrapped_lines:
                if first_line:
                    Output.message("{0} {1:<{2}} {3} {0}".format(
                        VERTICAL,
                        name + ":", max_title_length,
                        Utils.color_cell(line, max_data_length, "<")
                    ))
                    first_line = False  # Set flag to False after printing the first line
                else:
                    Output.message("{0} {1:<{2}} {3} {0}".format(
                        VERTICAL,
                        "",
                        max_title_length,
                        Utils.color_cell(line, max_data_length, "<")
                    ))

        # Bottom border of the box
        Output.message(LOWER_LEFT + HORIZONTAL * max_length + LOWER_RIGHT + "\n")

