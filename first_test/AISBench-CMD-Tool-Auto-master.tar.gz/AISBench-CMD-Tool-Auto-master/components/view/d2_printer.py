# coding:utf-8
# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.
"""
Description: cmd views
Copyright: Copyright © Huawei Technologies Co., Ltd. 2025. All rights reserved.
Python version: 3.7
"""
from components.utils.logger import Output
from components.utils.utils import Utils

CELL_SPE = " " * 4
TABLE_MARGIN = " " * 2


class D2Printer:
    max_length = 50
    alignment = "<"
    auto_adjust = False  # ucd要求不自动切表
    table_max_width = max(Utils.get_term_size()[0] - 10, 90)  # 最小宽度90
    table_key = None

    @staticmethod
    def transform_string(input_string, target_char, trans_char, leave_char):
        # 使用列表推导式进行转换
        transformed = ''.join([trans_char if char == target_char else leave_char for char in input_string])
        return transformed

    @staticmethod
    def convert_dict(original_dict, headers):
        if not headers:
            return original_dict
        converted_dict = {}
        for info_key, info_value in original_dict.items():
            temp_dict = {}
            if not isinstance(info_value, dict):
                continue
            for header in headers:
                if not isinstance(header, str):
                    continue
                temp_dict[header] = info_value.get(header, "NA")
            converted_dict[info_key] = temp_dict
        return converted_dict

    @classmethod
    def get_max_width_dict(cls, clean_dict, max_length):
        # 提取第一个元素的键作为列名
        column_name_list = list(list(clean_dict.values())[0].keys())

        # 计算每列的最大宽度
        max_widths = {col: Utils.get_text_real_length(col) for col in column_name_list}  # 初始宽度为列名长度

        # 计算每列的最大内容长度（包括列名和内容），确保最大宽度不超过max_length
        for _, details in clean_dict.items():
            if not isinstance(details, dict):
                continue
            row = [details.get(key, "--") for key in column_name_list]
            for col, val in zip(column_name_list, row):
                val_max = max(Utils.get_text_real_length(line) for line in str(val).split(';'))
                max_widths[col] = min(max_length, max(max_widths[col], val_max))
        return max_widths

    @classmethod
    def display_table_info(cls, info_dict: dict, module_name='', alignments=None, note=None, advanced=False,
                           display_headers=None):
        """
        Display info in table style with auto-adjusting column widths.
        If any cell content exceeds 50 characters, it will be split into multiple lines.
        """

        if module_name:
            Output.message("{}:".format(module_name))
        if note:
            Output.message("\033[1m{}\033[0m:\n{}".format("Note", note))
        if not info_dict or not isinstance(info_dict, dict):
            return
        if not alignments:
            alignments = {}
        info_dict = Utils.remove_hidden_dict(info_dict)
        # headers为二维数组，按输入的headers打印，不切割
        if display_headers and isinstance(display_headers, list) and isinstance(display_headers[0], list):
            for headers in display_headers:
                cls.display_sample_table(cls.convert_dict(info_dict, headers), alignments, advanced)
            return
        # 其他情况按参数切割
        if cls.auto_adjust:
            cls.adjust_display_table(cls.convert_dict(info_dict, display_headers), alignments, advanced)
        else:
            cls.display_sample_table(cls.convert_dict(info_dict, display_headers), alignments, advanced)

    @classmethod
    def adjust_display_table(cls, info_dict: dict, alignments=None, advanced=False):
        def group_keys_by_width(width_dict, max_width, table_key):
            """切割table，返回key二维数组"""
            result = []  # 存储最终的分组结果
            current_group = []  # 当前正在处理的键分组
            current_sum = 0  # 当前分组的宽度总和

            for key, width in width_dict.items():
                # 检查添加当前键是否会超过max_width
                if current_sum + width > max_width:
                    if current_group:  # 当前组非空时保存当前组
                        result.append(current_group)
                        current_group = [table_key]  # 后续数组把标识key加进去
                        current_sum = width_dict[table_key] + 4
                # 将当前键加入分组并更新宽度总和
                current_group.append(key)
                current_sum += width + 4  # 3为空格长度

            # 循环结束后检查最后一个分组
            if current_group:
                result.append(current_group)
            return result

        # 自动调整打印，超过table_max_width的分成多个个table打印
        max_widths = cls.get_max_width_dict(info_dict, cls.max_length)
        table_width = sum(max_widths.values()) + 4 * len(max_widths)
        if table_width >= cls.table_max_width:
            if not cls.table_key:
                info_key = list(info_dict.keys())[0]
                info_value = info_dict.get(info_key)
                cls.table_key = list(info_value.keys())[0]
            table_header_list = group_keys_by_width(max_widths, cls.table_max_width, cls.table_key)
            for headers in table_header_list:
                cls.display_sample_table(cls.convert_dict(info_dict, headers), alignments, advanced)
        else:
            cls.display_sample_table(info_dict, alignments, advanced)

    @classmethod
    def display_sample_table(cls, info_dict: dict, alignments=None, advanced=False):
        max_length = cls.max_length
        # 提取第一个元素的键作为列名
        column_name_list = list(list(info_dict.values())[0].keys())

        # 计算每列的最大宽度
        max_widths = cls.get_max_width_dict(info_dict, max_length)
        line_template, real_header_length = cls._display_title(advanced, alignments, column_name_list, max_widths)
        index = 0
        # 打印每行数据
        for _, details in info_dict.items():
            if not isinstance(details, dict):
                continue
            row = [details.get(key, "--") for key in column_name_list]

            # 计算每行单元格内容分行后的最大行数
            rows_to_print = []
            max_lines = 1
            for _, (val, col) in enumerate(zip(row, column_name_list)):
                wrapped_lines = Utils.split_text(str(val), max_length)
                max_lines = max(max_lines, len(wrapped_lines))
                rows_to_print.append(wrapped_lines)
            cls._display_detail_info(max_widths, max_lines, rows_to_print, column_name_list, advanced,
                                     alignments=alignments)
            # 打印行分隔符
            if index < len(info_dict) - 1:
                if advanced:
                    Output.message('╟─' + cls.transform_string(line_template, '│', '┼', '┈') + '─╢')
                index += 1
            else:
                if advanced:
                    Output.message('╚═' + cls.transform_string(line_template, '│', '╧', '═') + '═╝')
                else:
                    Output.message('─' * real_header_length + "\n")  # 打印横线

    @classmethod
    def _display_title(cls, advanced, alignments, column_name_list, max_widths):
        line_template = " │ ".join(
            [' ' * max_widths[name] for name in column_name_list]
        )
        real_header_length = sum(list(max_widths.values())) + len(max_widths) * 4
        content_list = []
        for name in column_name_list:
            alignment = cls.alignment
            if isinstance(alignments, dict):
                alignment = alignments.get(name, "<")
            content_list.append(Utils.color_cell(name, max_widths[name], alignment))
        if advanced:
            # 打印表头
            header = " │ ".join(content_list)
            Output.message('╔═' + cls.transform_string(line_template, '│', '╤', '═') + '═╗')  # 打印上横线
            Output.message('║ ' + header + ' ║')
            Output.message('╠═' + cls.transform_string(line_template, '│', '╪', '═') + '═╣')  # 打印下横线
        else:
            # 打印表头
            content_list = ["\033[1m{}\033[0m".format(content) for content in content_list]
            header = CELL_SPE.join(content_list)
            Output.message('─' * real_header_length)  # 打印横线
            Output.message(TABLE_MARGIN + header + TABLE_MARGIN)
            Output.message('─' * real_header_length)  # 打印横线
        return line_template, real_header_length

    @classmethod
    def _display_detail_info(cls, max_widths: dict, max_lines: int, rows_to_print: list, column_name_list: list,
                             advanced: bool, alignments=None):
        # 打印分行后的数据
        for i in range(max_lines):
            line = []
            for idx, lines in enumerate(rows_to_print):
                alignment = cls.alignment
                if isinstance(alignments, dict):
                    alignment = alignments.get(column_name_list[idx], "<")
                # 如果该单元格有足够的行，取出该行的内容；否则使用空字符串填充
                if i < len(lines):
                    line.append(Utils.color_cell(lines[i], max_widths[column_name_list[idx]], alignment))
                else:
                    line.append(" " * max_widths[column_name_list[idx]])
            if advanced:
                Output.message('║ ' + " │ ".join(line) + ' ║')
            else:
                Output.message(TABLE_MARGIN + CELL_SPE.join(line) + TABLE_MARGIN)
