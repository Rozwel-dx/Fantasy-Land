#!/usr/bin/env python
# _*_ encoding:utf-8 _*_
# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.
import locale
import os


class LanguageType:
    EN = 'en'
    ZH = 'zh'


class Language:
    language = LanguageType.EN

    @classmethod
    def check_language(cls):
        # 获取当前语言环境
        lang = locale.getdefaultlocale()
        # 检查语言环境是否包含中文
        if lang and lang[0] and (LanguageType.ZH in lang[0]):
            cls.language = LanguageType.ZH
            return True

        # 检查终端编码
        encoding = os.environ.get('LANG', '')
        if 'UTF-8' in encoding:
            cls.language = LanguageType.ZH
            return True
        cls.language = LanguageType.EN
        return False

    @classmethod
    def set_language(cls, language):
        if language in [0, LanguageType.EN]:
            cls.language = LanguageType.EN
        elif language in [1, LanguageType.ZH]:
            _ = cls.check_language()


class MsgHandle:
    def __init__(self, en, zh):
        self.en = en
        self.zh = zh

    def get_en_message(self, name):
        if hasattr(self.en, name):
            en_msg = getattr(self.en, name)
            return en_msg if en_msg else ''
        return ''

    def get_zh_message(self, name):
        if hasattr(self.zh, name):
            zh_msg = getattr(self.zh, name)
            return zh_msg if zh_msg else ''
        return self.get_en_message(name)


class Msg:

    def __init__(self, name, handle: MsgHandle):
        self.name = name
        self.handle = handle
        self.zh = handle.get_zh_message(name)
        self.en = handle.get_en_message(name)

    def __str__(self):
        return self.msg()

    def __add__(self, other):
        if not isinstance(other, str):
            return NotImplemented
        return self.msg() + other

    def format(self, format_spec, *args, **kwargs):
        en = self.en.format(format_spec, *args, **kwargs)
        zh = self.zh.format(format_spec, *args, **kwargs)
        return MsgExtend(zh, en)

    def append_msg(self, msg):
        if not isinstance(msg, (Msg, MsgExtend)):
            return NotImplemented
        zh = self.zh + msg.zh
        en = self.en + msg.en
        return MsgExtend(zh, en)

    def strip(self):
        return self.msg().strip()

    def splitlines(self):
        return self.msg().splitlines()

    def msg(self):
        if Language.language == LanguageType.ZH:
            return self.zh
        if Language.language == LanguageType.EN:
            return self.en
        return ''


class MsgExtend:
    def __init__(self, zh="", en=""):
        self.zh = zh if zh else en
        self.en = en if en else zh

    def __str__(self):
        return self.msg()

    def __add__(self, other):
        if isinstance(other, MsgExtend):
            return self.msg() + str(other)
        elif isinstance(other, str):
            return self.msg() + other
        return NotImplemented

    def __hash__(self):
        return hash(self.zh + self.en)

    def __eq__(self, other):
        if isinstance(other, MsgExtend) and self.zh == other.zh and self.en == other.en:
            return True
        return False

    def strip(self):
        return self.msg().strip()

    def append(self, other1='', other2=''):
        if not isinstance(other1, str) or not isinstance(other2, str):
            return NotImplemented
        self.zh += other1
        self.en += other2 if other2 else other1
        return self

    def append_msg(self, msg):
        if not isinstance(msg, (Msg, MsgExtend)):
            return NotImplemented
        self.zh += msg.zh
        self.en += msg.en
        return self

    def format(self, format_spec, *args, **kwargs):
        en = self.en.format(format_spec, *args, **kwargs)
        zh = self.zh.format(format_spec, *args, **kwargs)
        return MsgExtend(zh, en)

    def msg(self):
        if Language.language == LanguageType.ZH:
            return self.zh
        if Language.language == LanguageType.EN:
            return self.en
        return ''
