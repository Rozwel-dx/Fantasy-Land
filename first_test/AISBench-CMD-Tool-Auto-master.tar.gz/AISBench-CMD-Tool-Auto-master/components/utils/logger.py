#!/usr/bin/env python
# _*_ encoding:utf-8 _*_
# Copyright Huawei Technologies Co., Ltd. 2024. All rights reserved.
import configparser
import json
import logging
import os
import sys

from components.utils.path_util import PathUtil

MAX_LOG_MSG_SIZE = 2048
LOG_FORMAT = "[%(asctime)s] [%(levelname)s] [ProcessID:%(process)d] [%(filename)s:%(funcName)s:%(lineno)d] %(message)s"
DATE_FORMAT = '%Y-%m-%d %H:%M:%S'
COMMON_LOGGER_NAME = "common"


class Color:
    default_format = "\033[38m%s\033[0m"
    red_format = "\033[31m%s\033[0m"
    green_format = "\033[32m%s\033[0m"
    yellow_format = "\033[33m%s\033[0m"
    blue_format = "\033[34m%s\033[0m"
    bold_format = "\033[1m%s\033[0m"


class LogHandler(logging.Handler):
    def __init__(self, **kwargs):
        super().__init__()
        self.component_name = kwargs.get('component_name')
        self.tag_name = kwargs.get('tag_name')

    def format(self, record):
        msg = super().format(record)
        msg = msg.replace("\n", "\\n")
        if len(msg) > MAX_LOG_MSG_SIZE:
            msg = msg[:MAX_LOG_MSG_SIZE] + "..."
        return msg


class LoggerHandler:
    COMMON = logging.getLogger('common')
    logger_name_to_logger_dict = {}

    @staticmethod
    def compare_cfg(json_path, log_path, plugin_name):
        try:
            with open(json_path, 'r', errors='ignore') as log_config_file:
                log_info = json.load(log_config_file)
                if log_info.get(plugin_name, '') == log_path:
                    return True
            return False
        except Exception as exp:
            LoggerHandler.COMMON.error(exp)
            return False

    @staticmethod
    def logger_create(log_file_name, logger_name):
        """
        创建logger对象并配置日志处理器
        """
        # 检查并返回已存在的logger
        logger = LoggerHandler.logger_name_to_logger_dict.get(logger_name)
        if logger:
            return logger

        # 创建新的logger
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.NOTSET)  # 设置日志记录级别

        # 创建日志文件路径
        log_dir_path = PathUtil.get_log_root_dir_path()  # 获取根目录路径
        log_file_path = os.path.join(log_dir_path, log_file_name)

        # 检查日志文件是否存在，如果不存在则创建
        if not os.path.exists(log_file_path):
            # 如果日志文件目录不存在，则先创建目录
            os.makedirs(log_dir_path, 0o700, exist_ok=True)
            # 创建空文件
            with os.fdopen(os.open(log_file_path, os.O_WRONLY | os.O_CREAT, 0o600), 'wb'):
                pass

        # 创建FileHandler用于将日志输出到文件
        file_handler = logging.FileHandler(log_file_path, mode='a', encoding='utf-8')
        file_handler.setLevel(logging.NOTSET)  # 设置FileHandler的日志级别
        file_handler.setFormatter(logging.Formatter(LOG_FORMAT, DATE_FORMAT))

        # 将Handler添加到logger
        logger.addHandler(file_handler)

        # 将logger添加到缓存字典中
        LoggerHandler.logger_name_to_logger_dict[logger_name] = logger

        return logger

    @staticmethod
    def get_common_logger():
        """
        获取 common logger
        """
        return LoggerHandler.COMMON

    @staticmethod
    def set_log_level(log_level: int):
        """
        设置日志等级，默认CRITICAL；项目不使用CRITICAL，故不会打印任何日志
        """
        level_map = {
            0: logging.DEBUG,
            1: logging.INFO,
            2: logging.WARNING,
            3: logging.ERROR,
            4: logging.CRITICAL,
        }
        LoggerHandler.COMMON.setLevel(level_map.get(log_level, logging.CRITICAL))


class Output(object):
    stderr_only = False
    is_debug = False
    color_format = Color.default_format

    @classmethod
    def format_severity(cls, severity):
        return '[%s] ' % severity if severity else ''

    @classmethod
    def debug_message(cls, *args):
        cls.color_format = Color.blue_format
        return cls.do_message(True, sys.stdout, 'DEBUG', *args)

    @classmethod
    def bold_message(cls, *args):
        cls.color_format = Color.bold_format
        return cls.do_message(True, sys.stdout, '', *args)

    @classmethod
    def message(cls, *args):
        cls.color_format = Color.default_format
        return cls.do_message(True, sys.stdout, '', *args)

    @classmethod
    def message_without_wrap(cls, *args):
        cls.color_format = Color.default_format
        return cls.do_message(False, sys.stdout, '', *args)

    @classmethod
    def info_message(cls, *args):
        cls.color_format = Color.green_format
        return cls.do_message(True, sys.stdout, 'INFO', *args)

    @classmethod
    def warning_message(cls, *args):
        cls.color_format = Color.yellow_format
        return cls.do_message(True, sys.stdout, 'WARNING', *args)

    @classmethod
    def error_message(cls, *args):
        cls.color_format = Color.red_format
        return cls.do_message(True, sys.stdout, 'ERROR', *args)

    @classmethod
    def do_message(cls, add_newline, destination, severity, *args):
        real_destination = sys.stderr if cls.stderr_only else destination
        out_format = ("%s%s\n" if add_newline else "%s%s")
        out_str = out_format % (cls.format_severity(severity), " ".join([str(a) for a in args]))
        out_msg = cls.color_format % out_str
        # Get the binary stream if it's a text stream
        binary_dest = real_destination.buffer if hasattr(real_destination, 'buffer') else real_destination
        binary_dest.write(out_msg.encode('utf-8', errors='ignore'))
        binary_dest.flush()


LOGGER = LoggerHandler.logger_create("common.log", "common")
