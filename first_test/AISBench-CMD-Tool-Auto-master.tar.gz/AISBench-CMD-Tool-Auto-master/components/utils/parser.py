# coding:utf-8
# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.
"""
Description: parser
Copyright: Copyright © Huawei Technologies Co., Ltd. 2025. All rights reserved.
Python version: 3.7
"""
import argparse

from components.utils.help_text import HelpText
from components.utils.language import Language
from components.utils.utils import Utils


class CustomArgumentParser(argparse.ArgumentParser):
    def __init__(self, *args, **kwargs):
        self.add_help = False
        super().__init__(*args, **kwargs)
        self.add_argument('-h', '-H', '--help', action='help', help=HelpText.HELP)

    def error(self, message):
        msg = "Error: {}.".format(message)
        Utils.log_error_and_exit(msg)

    def _get_value(self, action, arg_string):
        result = super()._get_value(action, arg_string)
        if '-l' in action.option_strings:
            Language.set_language(result)
        return result


class CustomFormatter(argparse.RawTextHelpFormatter):
    def _get_help_string(self, action):
        help_text = str(action.help)
        # 首先按换行符分割原始文本
        wrapped_lines = Utils.split_text(help_text)

        # 合并处理后的所有行并在末尾添加空格
        return '\n'.join(wrapped_lines) + '\n '
