#!/usr/bin/env python3
# -*-coding:utf-8-*-
# Copyright: Copyright (c) Huawei Technologies Co., Ltd. 2023-2023. All rights reserved.
"""
Create: 2023-01-17
Content: 公共路径常量类
"""
import os
import sys


class PathUtil:

    @staticmethod
    def get_root_dir_path():
        """
        获取安装路径的根路径
        """
        if hasattr(sys, "_MEIPASS"):
            return os.path.dirname(sys.executable)
        current_dir_path = os.path.dirname(__file__)
        root_dir_index = os.path.abspath(os.path.join(current_dir_path, "..", ".."))
        return root_dir_index

    @staticmethod
    def get_output_root_dir_path():
        """
        获取输出报告根目录
        """
        return os.path.join(PathUtil.get_root_dir_path(), 'output')

    @staticmethod
    def get_log_root_dir_path():
        """
        获取运行日志文件根目录
        """
        return os.path.join(PathUtil.get_root_dir_path(), 'logs')

    @staticmethod
    def get_resources_root_dir_path():
        """
        获取资源文件根目录
        """
        meipass = PathUtil._get_meipass()
        if hasattr(sys, "_MEIPASS"):
            return os.path.join(meipass, 'resources')
        return os.path.join(PathUtil.get_root_dir_path(), 'resources')

    @staticmethod
    def _get_meipass():
        return getattr(sys, '_MEIPASS', None)