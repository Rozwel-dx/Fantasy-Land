#!/usr/bin/env python
# _*_ encoding:utf-8 _*_
# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.

from components.utils.language import MsgHandle, Msg

MAX_TITLE_LENGTH_MODULE = 20
MAX_TITLE_LENGTH_DIFF = 40


class HelpTextEn:
    HELP = "Get help information and exit."
    EXIT_C = "\nProgram interrupted (Ctrl+C), exiting..."
    EXIT_Z = "\nProgram interrupted (Ctrl+C), exiting..."
    CLEANING = "Cleaning up resources..."
    COLLECTING = "\nCollecting, please wait..."
    WAIT = "\r{}  {}  collection in progress..."
    COLLECT_COMPLETED = "\rCollection completed. Total duration: {:.2f} seconds."

    AIS_PATH = "The installation path for AISBench."
    MODEL_PATH = "The model path."
    ENGINE = "Name of inference engine."
    SUMMARIZER = "Name of the result summary task."
    MAX_INPUT_LEN = ("Maximum input tokenids length, exceeding will be truncated, value range: [0, 1048576]; default is"
                     " off, value is 0. For multiple rounds of testing, you can separate them with commas.")
    MAX_OUTPUT_LEN = ("Maximum output length, value range: [0, 1048576]; default value is 20. For multiple rounds of "
                      "testing, the quantity must be the same as MAX_INPUT_LEN.")
    DATASET_LEN = "Dataset length, default value is 10. the quantity must be the same as MAX_INPUT_LEN."
    AUTO_TPOT = ("Specify TPOT automatic optimization, automatically adjust the maximum concurrency to approach the "
                 "TPOT (ms); default is off, value is 0.")
    AUTO_TPOT_METHOD = ("Automatic TPOT optimization method, default is adjusting the maximum concurrency (CON). If "
                        "selecting request frequency (RR), it is recommended to set the maximum concurrency value > "
                        "1024.")
    APPROACH_UPPER = ("Maximum concurrency/maximum request rate for TPOT automatic optimization, default value "
                      "is 256/10. It needs to be used with --AutoTPOT.")
    CONCURRENCY = ("Maximum concurrency, default value is 1. The quantity must be the same as MAX_INPUT_LEN. Invalid "
                   "when AUTO_REQUEST_RATE is enabled.")

    AUTO_REQUEST_RATE = ("Automatic request frequency switch. If enabled, it will iterate through the current "
                         "concurrent binary bit position indexes; e.g. with a concurrency of 18, the request "
                         "frequencies will be [0, 2, 4, 8, 16, 18].")
    REQUEST_RATE = ("Manually set request frequency, with a default value of 0. Invalid when AutoRequestRate or "
                    "AutoTPOT is enabled. For multiple rounds of testing, you can separate them with commas."
                    "\nNote: Total number of test cases = len(MAX_INPUT_LEN) * len(REQUEST_RATE)")
    DATASET_TYPE = "Dataset type, default is synthetic."

    LOG = ("Specify the print log level, 0(debug) | 1(info) | 2(warning) | 3(error) | 4(notset), "
           "default is 3(error).")
    LAN = ("Specifies the printing language, which is 0(en) | 1(zh) and defaults to 1(zh).\n"
           "Note: If the current environment does not support the selected language, 0(en) is used.")

    SET_REQUEST_NUM = "Total request number is not set, default is 4 times the concurrency: {}"

    DATASET_PROCESS_START = "Start processing dataset"
    DATASET_PROCESS_END = "Dataset processing completed"
    GSM8K_SKIP = "The gsm8k dataset {} already exists and is skipped."
    GSM8K_SUCCESS = "The gsm8k dataset {} was successfully generated."
    GSM8K_REPLACE = "The gsm8k dataset {} in AISBench has been replaced with {}."

    CONFIG_PROCESS_START = "Start processing configuration file"
    CONFIG_PROCESS_FINISH = "{} configuration file {} has been modified."
    CONFIG_PROCESS_END = "Configuration file processing completed"

    RUN_AISBENCH = "Start to run AISBench task {}, parameters: {}"
    RUN_COMPLETED = "AISBench task {} has been completed."
    ALL_TASKS_COMPLETED = "All tasks have been completed. A total of {} tasks were run."

    ADJUST_CONFIG = "Adjust {} : {} >>> {}."
    READ_PERFORMANCE_RESULT = "Successfully parsed performance report {}."
    APPROACH_TASK_BLOCKED = ("TPOT {} has not approached the expected value {}, prefill has reached the bottleneck, "
                             "task blocked.")
    APPROACH_TASK_SUCCESS = "TPOT {} has reached the expected value {}, this round of data will be displayed."

    COUNTDOWN_START = "Start waiting {}s: \n"
    PROCESS_BAR = "\rRemaining time: {:02d}:{:02d}:{:02d} |{}|"
    COUNTDOWN_FINISHED = "Waiting completed!"


class HelpTextZh:
    """
    ZH help信息类，格式：模块/功能+异常类型
    """
    HELP = "获取帮助信息并退出。"
    EXIT_C = "\n程序中断 (Ctrl+C)，退出..."
    EXIT_Z = "\n程序中断 (Ctrl+Z)，退出..."
    CLEANING = "正在清理资源..."
    COLLECTING = "\n采集中，请稍等..."
    WAIT = "\r{}  {}  采集进行中..."
    COLLECT_COMPLETED = "\r采集完成，总用时: {:.2f} 秒。                  "

    AIS_PATH = "指定AISBench安装路径。"
    MODEL_PATH = "指定模型路径。"
    ENGINE = "推理引擎名称。"
    SUMMARIZER = "指定结果总结任务名称。"
    MAX_INPUT_LEN = "最大输入tokenids长度，超过会截断，取值范围：[0，1048576]；默认不开启，取值为0。如需多轮测试，可用逗号隔开。"
    MAX_OUTPUT_LEN = "最大输出长度，取值范围：[0，1048576]；默认值20。维度需与MAX_INPUT_LEN相同。"
    DATASET_LEN = "数据集长度，默认值10。维度需与MAX_INPUT_LEN相同。"
    AUTO_TPOT = "指定TPOT自动寻优，自动调整最大并发/请求频率以适配TPOT (ms)；默认不开启，取值为0。"
    AUTO_TPOT_METHOD = "TPOT自动寻优方法，默认调整最大并发（CON）。若选择请求频率（RR），建议将最大并发值设置 > 1024"
    APPROACH_UPPER = "TPOT自动寻优最大并发数/请求频率上限，默认值为256/10。需配合--AutoTPOT使用。"
    CONCURRENCY = "最大并发数，默认值为1。维度需与MAX_INPUT_LEN相同。当AutoTPOT开启时，该参数失效。"

    AUTO_REQUEST_RATE = "自动请求频率开关，若开启则会遍历当前并发的二进制位位置索引；例：并发18，请求频率为[0, 2, 4, 8, 16, 18]"
    REQUEST_RATE = ("手动设置的请求频率，默认值为0。如需多轮测试，可用逗号隔开。当AutoRequestRate或AutoTPOT开启时该参数失效。"
                    "\n注：总计测试次数=len(MAX_INPUT_LEN) * len(REQUEST_RATE)")
    DATASET_TYPE = "数据集类型，默认值为合成数据集synthetic。"

    LAN = "指定打印语言，0(en) | 1(zh), 默认为 1(zh)。\n提示: 如果当前环境不支持所选语言，则会使用 0(en)。"
    LOG = "指定输出日志等级，0(debug) | 1(info) | 2(warning) | 3(error) | 4(notset) 默认为 3(error)。"

    SET_REQUEST_NUM = "未设置总请求次数，默认为四倍并发数：{}"

    DATASET_PROCESS_START = "开始处理数据集"
    DATASET_PROCESS_END = "数据集处理完成"
    GSM8K_SKIP = "gsm8k数据集{}已存在，跳过。"
    GSM8K_SUCCESS = "gsm8k数据集{}已成功生成。"
    GSM8K_REPLACE = "AISBench gsm8k数据集{}已被替换为{}。"

    CONFIG_PROCESS_START = "开始处理配置文件"
    CONFIG_PROCESS_FINISH = "{}配置文件{}已修改"
    CONFIG_PROCESS_END = "配置文件处理完成"

    RUN_AISBENCH = "开始运行AISBench任务{}，参数：{}。"
    RUN_COMPLETED = "AISBench任务{}运行完成。"
    ALL_TASKS_COMPLETED = "所有任务运行完成。共运行 {} 个。"

    ADJUST_CONFIG = "调整 {}：{} >>> {}。"
    READ_PERFORMANCE_RESULT = "解析性能报告{}成功。"
    APPROACH_TASK_BLOCKED = "TPOT {} 未接近预期值 {}，prefill 已达瓶颈，任务阻塞。"
    APPROACH_TASK_SUCCESS = "TPOT {} 已接近预期值 {}，此次数据将会展示。"

    COUNTDOWN_START = "开始任务冷却倒计时 {}s: "
    PROCESS_BAR = "\r剩余时间: {:02d}:{:02d}:{:02d} |{}|"
    COUNTDOWN_FINISHED = "任务冷却完成！"


class HelpText(HelpTextEn, HelpTextZh):
    """
    help信息枚举类，格式：模块/功能+异常类型
    """
    handle = MsgHandle(HelpTextEn, HelpTextZh)

    HELP = Msg('HELP', handle)
    EXIT_C = Msg('EXIT_C', handle)
    EXIT_Z = Msg('EXIT_Z', handle)
    CLEANING = Msg('CLEANING', handle)
    COLLECTING = Msg('COLLECTING', handle)
    WAIT = Msg('WAIT', handle)
    COLLECT_COMPLETED = Msg('COLLECT_COMPLETED', handle)

    AIS_PATH = Msg('AIS_PATH', handle)
    ENGINE = Msg('ENGINE', handle)
    SUMMARIZER = Msg('SUMMARIZER', handle)
    MODEL_PATH = Msg('MODEL_PATH', handle)
    MAX_INPUT_LEN = Msg('MAX_INPUT_LEN', handle)
    MAX_OUTPUT_LEN = Msg('MAX_OUTPUT_LEN', handle)
    DATASET_LEN = Msg('DATASET_LEN', handle)
    AUTO_TPOT = Msg('AUTO_TPOT', handle)
    AUTO_TPOT_METHOD = Msg('AUTO_TPOT_METHOD', handle)
    APPROACH_UPPER = Msg('APPROACH_UPPER', handle)
    CONCURRENCY = Msg('CONCURRENCY', handle)

    AUTO_REQUEST_RATE = Msg('AUTO_REQUEST_RATE', handle)
    REQUEST_RATE = Msg('REQUEST_RATE', handle)
    DATASET_TYPE = Msg('DATASET_TYPE', handle)

    LAN = Msg('LAN', handle)
    LOG = Msg('LOG', handle)

    SET_REQUEST_NUM = Msg('SET_REQUEST_NUM', handle)

    DATASET_PROCESS_START = Msg('DATASET_PROCESS_START', handle)
    DATASET_PROCESS_END = Msg('DATASET_PROCESS_END', handle)
    GSM8K_SKIP = Msg('GSM8K_SKIP', handle)
    GSM8K_SUCCESS = Msg('GSM8K_SUCCESS', handle)
    GSM8K_REPLACE = Msg('GSM8K_REPLACE', handle)

    CONFIG_PROCESS_START = Msg('CONFIG_PROCESS_START', handle)
    CONFIG_PROCESS_FINISH = Msg('CONFIG_PROCESS_FINISH', handle)
    CONFIG_PROCESS_END = Msg('CONFIG_PROCESS_END', handle)

    RUN_AISBENCH = Msg('RUN_AISBENCH', handle)
    RUN_COMPLETED = Msg('RUN_COMPLETED', handle)
    ALL_TASKS_COMPLETED = Msg('ALL_TASKS_COMPLETED', handle)

    ADJUST_CONFIG = Msg('ADJUST_CONFIG', handle)
    READ_PERFORMANCE_RESULT = Msg('READ_PERFORMANCE_RESULT', handle)
    APPROACH_TASK_BLOCKED = Msg('APPROACH_TASK_BLOCKED', handle)
    APPROACH_TASK_SUCCESS = Msg('APPROACH_TASK_SUCCESS', handle)

    COUNTDOWN_START = Msg('COUNTDOWN_START', handle)
    PROCESS_BAR = Msg('PROCESS_BAR', handle)
    COUNTDOWN_FINISHED = Msg('COUNTDOWN_FINISHED', handle)
