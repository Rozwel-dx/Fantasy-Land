import os
import re
import shutil
import subprocess
import sys

import unicodedata

from components.utils.errcode import ErrCode
from components.utils.logger import Output, LOGGER
from components.utils.path_util import PathUtil

LOGGER_PATH = PathUtil.get_log_root_dir_path() + '/common.log'

class CustomError(Exception):
    def __init__(self, message, code=2):
        super().__init__(message)
        self.message = message
        self.code = code


class CMDColor:
    NO_PRINT_IDENTIFIER = "(HIDDEN) "

    INFO = "(INFO)"
    WARNING = "(WARNING)"
    ERROR = "(ERROR)"
    SUGGESTION = "(SUGGESTION)"

    GREEN = "\033[32m{}\033[0m"
    RED = "\033[31m{}\033[0m"
    ORANGE = "\033[38;5;214m{}\033[0m"
    YELLOW = "\033[33m{}\033[0m"
    PINK = "\033[38;5;219m{}\033[0m"
    PURPLE = "\033[0;35m{}\033[0m"


class Utils:
    color_mapping = {
        CMDColor.INFO: CMDColor.GREEN,
        CMDColor.WARNING: CMDColor.YELLOW,
        CMDColor.ERROR: CMDColor.RED,
        CMDColor.SUGGESTION: CMDColor.PINK,
    }

    p = None

    @staticmethod
    def log_error_and_print(message):
        LOGGER.error(message)
        Output.error_message(str(message))

    @staticmethod
    def log_warning_and_print(message):
        LOGGER.warning(message)
        Output.warning_message(str(message))

    @staticmethod
    def log_info_and_print(message):
        LOGGER.info(message)
        Output.info_message(str(message))

    @staticmethod
    def log_debug_and_print(message):
        LOGGER.debug(message)
        Output.debug_message(str(message))

    @staticmethod
    def log_error_and_exit(message, print_flag=True, message_args=(), code=2):
        if message_args:
            message = message.format(*message_args)
        LOGGER.error(message)
        if print_flag:
            Output.error_message(str(message))
        raise CustomError(message, code)

    @classmethod
    def split_identifier_and_text(cls, text):
        """
        识别文本中的颜色标识符，返回颜色标识符和无标识符文本
        """
        for identifier, _ in cls.color_mapping.items():
            if identifier in text:
                return identifier, text.replace(identifier, '')
        return "", text

    @staticmethod
    def from_ms_to_s(time_ms):
        """
        '214511.96 ms' -> '214.51196'
        :param time_ms:
        :return:
        """
        time_s = float(time_ms.replace(" ms", "")) / 1000
        return "{:.4f}".format(time_s)

    @staticmethod
    def get_term_size(default_width=120, default_height=24):
        """
        安全获取终端大小
        """
        try:
            size = shutil.get_terminal_size()
            return size.columns, size.lines
        except (OSError, AttributeError):
            return default_width, default_height

    @staticmethod
    def decode_data(byte_data: bytes):
        """
        解码数据
        :param byte_data: 待解码数据
        :return: 解码字符串
        """
        try:
            return byte_data.decode('UTF-8')
        except UnicodeDecodeError:
            return byte_data.decode('GB18030')

    @staticmethod
    def split_text(help_text, width=120):
        lines = help_text.splitlines()
        wrapped_lines = []
        for line in lines:
            color, line = Utils.split_identifier_and_text(line)
            current_line = ""
            current_width = 0

            for char in line:
                # 计算当前字符的宽度
                char_width = 2 if unicodedata.east_asian_width(char) in ('W', 'F') else 1

                # 如果加上当前字符会超出限制且当前行不为空，则换行
                if current_width + char_width > width and current_line:
                    wrapped_lines.append(color + current_line)
                    current_line = char
                    current_width = char_width
                else:
                    current_line += char
                    current_width += char_width

            # 添加最后一行
            if current_line:
                wrapped_lines.append(color + current_line)

        return wrapped_lines

    @staticmethod
    def check_no_print(text):
        return CMDColor.NO_PRINT_IDENTIFIER in text

    @classmethod
    def remove_hidden_dict(cls, input_dict):
        """
        移除字典中需要隐藏的字段，返回新字典
        """
        clean_dict = {}
        for key, value in input_dict.items():
            if not cls.check_no_print(str(key)):
                if isinstance(value, dict):
                    clean_dict[key] = Utils.remove_hidden_dict(value)
                else:
                    clean_dict[key] = str(value)
        return clean_dict

    @classmethod
    def get_text_real_length(cls, text):
        """
        计算文本长度（中文字符计为 2 个字符）
        """
        length = 0
        for char in str(text):
            char_width = 2 if unicodedata.east_asian_width(char) in ('W', 'F') else 1
            length += char_width
        return length

    @classmethod
    def run_command_with_realtime_output(cls, cmd):
        """
        开启子进程，执行对应指令，控制台打印执行过程，然后返回子进程执行的状态码和执行返回的数据
        :param cmd: 子进程命令
        :param shell: 是否开启shell
        :return: 子进程状态码和执行结果
        """
        LOGGER.info('\033[1;32m************** START **************\033[0m')
        cls.p = subprocess.Popen(cmd, shell=False, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        result = []
        while cls.p.poll() is None:
            line = cls.p.stdout.readline().strip()
            if line:
                line = Utils.decode_data(line)
                result.append(line)
                Output.message(line)
            # 清空缓存
            sys.stdout.flush()
            sys.stderr.flush()
        # 判断返回码状态
        returncode = cls.p.returncode
        if returncode == 0:
            LOGGER.info('\033[1;32m************** SUCCESS **************\033[0m')
        else:
            LOGGER.error('\033[1;31m************** FAILED **************\033[0m')
        cls.p = None
        return returncode, result

    @classmethod
    def kill_process(cls):
        if cls.p is not None and isinstance(cls.p, subprocess.Popen):
            cls.p.terminate()

    @classmethod
    def get_max_string_length(cls, info_dict, level=0):
        """
        Recursively get the maximum length of string values in the most inner level of a nested dictionary.
        """
        max_length = 0

        for value in info_dict.values():
            if isinstance(value, dict):
                # 如果值是字典，递归调用
                max_length = max(max_length, cls.get_max_string_length(value, level + 1))
            elif isinstance(value, str):
                # 如果值是字符串，获取长度
                split_value_list = value.splitlines()
                value_length = max(Utils.get_text_real_length(str(value)) for value in split_value_list)
                max_length = max(max_length, value_length)

        return max_length + 4 * level

    @staticmethod
    def color_cell(text, width, alignment=">"):
        text = str(text)
        # 计算填充后的文本宽度
        display_width = Utils.get_text_real_length(text)

        # 计算剩余宽度以进行填充
        remaining_width = width - display_width

        # 根据对齐方式生成填充文本
        if alignment == "<":
            formatted_text = text + " " * remaining_width
        elif alignment == ">":
            formatted_text = " " * remaining_width + text
        else:
            # 默认居中对齐
            left_padding = remaining_width // 2
            right_padding = remaining_width - left_padding
            formatted_text = " " * left_padding + text + " " * right_padding

        return formatted_text

    @staticmethod
    def parse_range(range_str, range_type):
        # 解析类似 '0', '0,1', '0,1.8,2.1' 的字符串
        if not range_str:
            LOGGER.error("Empty range.")
            return []
        if not bool(re.fullmatch(r'[0-9,.]*', range_str)):
            Utils.log_error_and_exit(ErrCode.RANGE_INVALID_FORMAT.format(range_str))
        range_list = range_str.split(',')
        for i in range(len(range_list)):
            try:
                range_list[i] = range_type(range_list[i])
            except ValueError:
                Utils.log_error_and_exit(ErrCode.RANGE_INVALID_FORMAT.format(range_str))
        return range_list

    @staticmethod
    def get_powers_of_two(n):
        if n <= 0:
            return [0]  # 如果输入 ≤ 0，默认返回 [0]

        power = 1
        powers = [0]  # 默认包含0

        while power < n:
            powers.append(power)
            power *= 2

        return powers

    @staticmethod
    def make_dirs(dir_path):
        # 检查路径是否存在，如果不存在则创建
        if not os.path.exists(dir_path):
            LOGGER.info("Generate path: {}.".format(dir_path))
            os.makedirs(dir_path, 0o700)




