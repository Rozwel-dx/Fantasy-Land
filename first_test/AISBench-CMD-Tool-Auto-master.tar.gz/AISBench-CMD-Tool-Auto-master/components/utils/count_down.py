import time
import sys

from components.utils.help_text import HelpText
from components.utils.utils import Utils


class CountDown:
    @classmethod
    def countdown_with_progress(cls, total_seconds):
        """
        带进度条的倒计时（实时刷新）
        """
        Utils.log_info_and_print(HelpText.COUNTDOWN_START.format(total_seconds))

        for remaining in range(total_seconds, -1, -1):
            # 时间转换
            hours, remainder = divmod(remaining, 3600)
            minutes, seconds = divmod(remainder, 60)

            # 进度条（20格）
            progress = int((total_seconds - remaining) / total_seconds * 20)
            progress_bar = "█" * progress + " " * (20 - progress)

            # 输出格式化
            timer_str = str(HelpText.PROCESS_BAR.format(hours, minutes, seconds, progress_bar))
            sys.stdout.write(timer_str)
            sys.stdout.flush()

            time.sleep(1)
        sys.stdout.write('\n')
        Utils.log_info_and_print(HelpText.COUNTDOWN_FINISHED)
