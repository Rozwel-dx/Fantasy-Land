#!/usr/bin/env python
# _*_ encoding:utf-8 _*_
# Copyright Huawei Technologies Co., Ltd. 2025. All rights reserved.

from components.utils.language import Msg, MsgHandle


class ErrorMsgEn:
    """
    EN 错误码类，格式：模块/功能+异常类型
    """

    # 通用
    SUCCESS = "Succeeded"
    EXIT = "Exit"
    COMMON_ERROR = "Unknown error, please check logs {} for details."

    RUN_ERROR = "AISBench task {} run failed, please check logs {} for details."
    NO_PERFORMANCE_RESULT = "No performance result data obtained."

    RANGE_INVALID_FORMAT = "{} parameter range format error."
    AISBENCH_NOT_EXIST = "AISBench path does not exist."
    MODEL_NOT_EXIST = "Tokenizer path does not exist."
    INPUT_OUTPUT_DATASET_NOT_MATCH = "Input and output lengths do not match the dataset."


class ErrorMsgZh:
    """
    ZH 错误码类，格式：模块/功能+异常类型
    """
    # 通用
    SUCCESS = "成功"
    EXIT = "退出"
    COMMON_ERROR = "未知错误，详情请查看日志 {}。"

    RUN_ERROR = "AISBench任务{}运行失败，详情可查看日志 {}。"
    NO_PERFORMANCE_RESULT = "未获取到任务结果数据。"

    RANGE_INVALID_FORMAT = "{} 参数范围格式错误。"
    AISBENCH_NOT_EXIST = "AISBench 路径不存在。"
    MODEL_NOT_EXIST = "Tokenizer 路径不存在。"
    INPUT_OUTPUT_DATASET_NOT_MATCH = "输入输出长度、数据集和并发维度不匹配。"


class ErrCode(ErrorMsgEn, ErrorMsgZh):
    """
    错误码枚举类，格式：模块/功能+异常类型
    """
    handle = MsgHandle(ErrorMsgEn, ErrorMsgZh)

    # 通用
    SUCCESS = Msg('SUCCESS', handle)
    EXIT = Msg('EXIT', handle)
    COMMON_ERROR = Msg('COMMON_ERROR', handle)

    RUN_ERROR = Msg('RUN_ERROR', handle)
    NO_PERFORMANCE_RESULT = Msg('NO_PERFORMANCE_RESULT', handle)

    RANGE_INVALID_FORMAT = Msg('RANGE_INVALID_FORMAT', handle)
    AISBENCH_NOT_EXIST = Msg('AISBENCH_NOT_EXIST', handle)
    MODEL_NOT_EXIST = Msg('MODEL_NOT_EXIST', handle)
    INPUT_OUTPUT_DATASET_NOT_MATCH = Msg('INPUT_OUTPUT_DATASET_NOT_MATCH', handle)
