#!/bin/bash

# 获取当前脚本所在目录
SCRIPT_DIR=$(dirname "$0")

# 检查是否有 python3
if command -v python3 &>/dev/null; then
    PYTHON_CMD="python3"
else
    # 如果没有 python3，则使用 python
    if command -v python &>/dev/null; then
        PYTHON_CMD="python"
    else
        echo "Error: Python is not installed."
        exit 1
    fi
fi

# 执行 Python 脚本并传递所有的命令行参数
$PYTHON_CMD "${SCRIPT_DIR}/components/aisbench_auto.py" "$@"
