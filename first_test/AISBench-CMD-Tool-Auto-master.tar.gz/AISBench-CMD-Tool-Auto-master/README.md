# AISBench-CMD-Tool-Auto

AISBench批量任务自动化工具